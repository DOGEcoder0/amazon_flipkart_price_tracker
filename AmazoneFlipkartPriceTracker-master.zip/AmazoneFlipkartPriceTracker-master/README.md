# AmazoneFlipkartPriceTracker

## Email class -- used to send email
### Reduired module SMTPlib,ssl, email.mime.text, email.mime.multipart

#### set up the connection to our email account and send the formated email

## main class -- for price tarcking
### Required module  requests, BeautifulSoup  for accessing data from website
#### requests the input site and fetch the required data
